var user = document.getElementById("username"); 
var pass =  document.getElementById("password"); 
var btn = document.querySelector(".login-button"); 
  
 function checkvalidity(){ 
         if(user.value == "" || pass.value ==""){ 
             alert("Please provide Username & Password ") 
         } 
       else if(user.value == "Rishab" || pass.value =="12345"){ 
            
            window.location.href= "index.html"
        } 
        else if(user.value == "Admin" || pass.value =="12345"){ 
           // alert("Log in successful") 
        } 
        else{
            alert("Invalid Id or Password")
        }
  
 } 
  
 btn.addEventListener("click", checkvalidity)